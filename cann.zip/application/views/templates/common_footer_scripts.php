<!-- JAVASCRIPTS -->
	<!-- Placed at the end of the document so the pages load faster -->
	<!-- JQUERY -->
	<script src="<?php echo base_url('resources/js/jquery/jquery-2.0.3.min.js');?>"></script>
	<!-- JQUERY UI-->
	<script src="<?php echo base_url('resources/js/jquery-ui-1.10.3.custom/js/jquery-ui-1.10.3.custom.min.js');?>"></script>
	<!-- BOOTSTRAP -->
	<script src="<?php echo base_url('resources/bootstrap-dist/js/bootstrap.min.js');?>"></script>
        <!-- HUBSPOT MESSENGER -->
	<script type="text/javascript" src="<?php echo base_url('resources/js/hubspot-messenger/js/messenger.min.js');?>"></script>
	<script type="text/javascript" src="<?php echo base_url('resources/js/hubspot-messenger/js/messenger-theme-flat.js');?>"></script>
